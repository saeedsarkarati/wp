from PyQt6.QtGui import QPalette
palette = QPalette()